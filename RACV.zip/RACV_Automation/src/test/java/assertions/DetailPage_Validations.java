package assertions;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import utility.PropertyReader;
import utility.SnapShots;

public class DetailPage_Validations {
	
public static void FNameShouldBe(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
		
				
		String s=driver.findElement(By.xpath(PropertyReader.getValidationMessage("Fname"))).getText();
		System.out.println(s);
		
		if(s.trim().equalsIgnoreCase(expValidation))
		{
			t1.log(LogStatus.PASS, "First name validation met with expected text");
		    report.endTest(t1);
		    
			Assert.assertTrue(true);
			
		}
		else
		{
			t1.log(LogStatus.FAIL, "Validation Message not met with expected first name validation message");
		    report.endTest(t1);
		    SnapShots.takeScreenshot(driver, "Validation Message not met with expected validation message for first name");
			Assert.assertTrue(false);
	         
		}
	}


public static void LNameShouldBe(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	
	String s=driver.findElement(By.xpath(PropertyReader.getValidationMessage("Lname"))).getText();
	System.out.println(s);
	
	if(s.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "Last name validation met with expected text");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Validation Message not met with expected last name validation message");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Validation Message not met with expected validation message for last name");
		Assert.assertTrue(false);
         
	}
}

public static void DOBShouldBe(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	
	String s=driver.findElement(By.xpath(PropertyReader.getValidationMessage("DOB"))).getText();
	System.out.println(s);
	
	if(s.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "Date of birth validation met with expected text");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Validation Message not met with expected DOB validation message");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Validation Message not met with expected validation message for DOB");
		Assert.assertTrue(false);
         
	}
}


public static void AddressShouldBe(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	
	String s=driver.findElement(By.xpath(PropertyReader.getValidationMessage("Address"))).getText();
	System.out.println(s);
	
	if(s.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "Address validation met with expected text");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Validation Message not met with expected Address validation message");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Validation Message not met with expected validation message for Address");
		Assert.assertTrue(false);
         
	}
}

public static void SubrbShouldBe(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	
	String s=driver.findElement(By.xpath(PropertyReader.getValidationMessage("Subrb"))).getText();
	System.out.println(s);
	
	if(s.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "Subrb validation met with expected text");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Validation Message not met with expected Subrb validation message");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Validation Message not met with expected validation message for Subrb");
		Assert.assertTrue(false);
         
	}
}

public static void StateShouldBe(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	
	String s=driver.findElement(By.xpath(PropertyReader.getValidationMessage("stte"))).getText();
	System.out.println(s);
	
	if(s.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "State validation met with expected text");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Validation Message not met with expected State validation message");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Validation Message not met with expected validation message for State");
		Assert.assertTrue(false);
         
	}
}

public static void PostCodeShouldBe(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	
	String s=driver.findElement(By.xpath(PropertyReader.getValidationMessage("Pcode"))).getText();
	System.out.println(s);
	
	if(s.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "PostCode validation met with expected text");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Validation Message not met with expected PostCode validation message");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Validation Message not met with expected validation message for PostCode");
		Assert.assertTrue(false);
         
	}
}

public static void EmailAddShouldBe(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	
	String s=driver.findElement(By.xpath(PropertyReader.getValidationMessage("mail"))).getText();
	System.out.println(s);
	
	if(s.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "Email Address validation met with expected text");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Validation Message not met with expected Email Address validation message");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Validation Message not met with expected validation message for Email Address");
		Assert.assertTrue(false);
         
	}
}

public static void CnfEmailAddShouldBe(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	
	String s=driver.findElement(By.xpath(PropertyReader.getValidationMessage("cnfmail"))).getText();
	System.out.println(s);
	
	if(s.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "Confirm Email Address validation met with expected text");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Validation Message not met with expected Confirm Email Address validation message");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Validation Message not met with expected validation message for Confirm Email Address");
		Assert.assertTrue(false);
         
	}
}

public static void PhoneShouldBe(WebDriver driver , String expValidation, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException {
	
	
	String s=driver.findElement(By.xpath(PropertyReader.getValidationMessage("mob"))).getText();
	System.out.println(s);
	
	if(s.trim().equalsIgnoreCase(expValidation))
	{
		t1.log(LogStatus.PASS, "Phone Number validation met with expected text");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Validation Message not met with expected Phone Number validation message");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Validation Message not met with expected validation message for Phone Number");
		Assert.assertTrue(false);
         
	}
}
}
