package assertions;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Test_Case_Coverage {
	
	public static void Single_Trip_Annual_multi_trip(WebDriver driver , ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Single Trip Annual multi trip");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	
	public static void Get_an_Instant_Quote(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Get an Instant Quote");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}

	public static void Travel_Destination(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Travel Destination");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}

	public static void Leaving_On(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Leaving On");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Returning_On(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Returning On");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Age_of_Traveller_Primary(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Age_of_Traveller_(Primary)");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Age_of_Traveller_Secondary(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Age_of_Traveller_(Secondary)");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	
	public static void Number_of_dependents(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "No._of_dependents");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	
	public static void RACV_Membership_Entry_Box_Dropdown_Box(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "RACV_Membership_Entry_Box/Dropdown_Box");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Disclaimer_text(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Disclaimer_text");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	
	public static void Choose_your_excess(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Choose_your_excess");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	
	public static void Going_on_a_cruise(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Going_on_a_cruise?");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	
	public static void Ski_Winter_Sports(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Ski/Winter_Sports?");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Coverage_1_and_its_equivalent_limit(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "<Coverage 1>_and_its_equivalent_<limit> ");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Coverage_2_and_its_equivalent_limit(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "<Coverage 2>_and_its_equivalent_<limit> ");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	
	public static void Coverage_3_and_its_equivalent_limit(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "<Coverage 3>_and_its_equivalent_<limit> ");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Show_All_Benefits(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Show_All_Benefits");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	
	public static void Quote_Summary_in_Header_Section(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Quote_Summary_in_Header_Section");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Edit_button_in_Summary_Section_and_to_the_Right_of_Quote_Summary(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Edit_button_in Summary_Section_and_to_the_Right_of_Quote_Summary");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Continue_Button_in_Summary_Section(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Continue_Button_in_Summary_Section");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void First_Name_Primary_Traveler_in_Traveler_Details_Section(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "First_Name_(Primary Traveler)_in_Traveler_Details_Section");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	
	public static void Last_name_Primary_Traveler(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Last_name_(Primary Traveler)");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Date_of_Birth_Primary_Traveler(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Date_of_Birth(Primary Traveler)");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	
	public static void First_Name_Secondary_Traveler(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "First_Name_(Secondary Traveler)");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Last_Name_Secondary_Traveler(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Last_Name_(Secondary Traveler)");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Street_Address_Primary_Traveler(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Street_Address_(Primary Traveler) ");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	
	public static void Street_Address_Secondry_Traveler(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Street_Address_(Secondry Traveler) ");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Suburb(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Suburb");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void State(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "State");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Postal_Code(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Postal_Code");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Email_Address(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Email_Address");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Confirm_Email_Address(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Confirm_Email_Address");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Phone_number(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Phone_number");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	
	public static void Dependent1_First_name(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Dependent1_First_name");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Dependent1_Last_name(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Dependent1_Last_name");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Dependent1_DOB(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Dependent1_DOB");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Remove_button_in_dependent_details_section(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Remove_button_in_dependent_details_section");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Confirm_your_details_Button(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Confirm_your_details_Button");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Confirmation_Finalise_Quote_button(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Confirmation_Finalise_Quote_button");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Traveler_details_with_pre_medical_conditions(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Traveler details with pre-medical conditions -->Adult_Travelers_in_Pre_existing_medical_check_section");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void 
	Verify_that_user_select_only_one_selection_box_Yes_No(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Verify_that_user_select_only_one_selection_box_Yes_No");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Continue_button_below_Pre_existing_medical_check_section(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Continue_button_below_Pre_existing_medical_check_section");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Assess_button_on_the_right_side_to_Selection_box_against_each_traveller(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Assess_button_on_the_right_side_to_Selection_box_against_each_traveller");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Validate_selection_box_with_Yes_No_option_for_assessment_question_1_Person_travelling_against_medical_advice(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Validate_selection_box_with_Yes_No_option_for_assessment_question_1_Person_travelling_against_medical_advice?");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Continue(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Continue");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Disclaimer_with_Yes_No_button(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Disclaimer_with_Yes_No_button");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Marketing_Content_hyperlink_in_Marketing_Section_with_Yes_No_button(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Marketing_Content_hyperlink_in_Marketing_Section_with_Yes_No_button");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Confirm_and_Pay_button(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Confirm_and_Pay_button");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
	public static void Cancel(WebDriver driver, ExtentReports report, ExtentTest t1) throws InterruptedException, IOException
	{
		t1.log(LogStatus.PASS, "Cancel");
	    report.endTest(t1);
	    
		Assert.assertTrue(true);

}
}
