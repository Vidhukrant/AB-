package assertions;

import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import utility.PropertyReader;
import utility.SnapShots;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ValidatePage {
	
public static void PageURLShouldBe(WebDriver driver , String expURL, ExtentReports report, ExtentTest t1) throws IOException{
	

		
		if(driver.getCurrentUrl().equalsIgnoreCase(expURL))
		{
			t1.log(LogStatus.PASS, "Logged in Successfully");
		    report.endTest(t1);
		    SnapShots.takeScreenshot(driver, "Payment successfully done");
			Assert.assertTrue(true);
			
		}
		else
		{
			t1.log(LogStatus.FAIL, "Logged Failed");
		    report.endTest(t1);
		    SnapShots.takeScreenshot(driver, "Payment failed");
			Assert.assertTrue(false);
	         
		}
	}
	
public static void PageTitleShouldBe(WebDriver driver , String expTitle, ExtentReports report, ExtentTest t1) throws IOException{
		
		if(driver.getTitle().trim().equalsIgnoreCase(expTitle))
		{
			t1.log(LogStatus.PASS, "Logged in Successfully");
		    report.endTest(t1);
			Assert.assertTrue(true);
			
		}
		else
		{
			t1.log(LogStatus.FAIL, "Logged Failed");
		    report.endTest(t1);
		    SnapShots.takeScreenshot(driver, "AfterLogin");
			Assert.assertTrue(false);
	         
		}
	}
	
	

public static void AlertmessageShouldBe(WebDriver driver , Alert alt,String expTitle, ExtentReports report, ExtentTest t1) throws IOException{
	alt=driver.switchTo().alert();
	String S1=alt.getText();
	
	if(S1.equalsIgnoreCase(expTitle))
	{
		t1.log(LogStatus.PASS, "Quote Bind Successfully");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "After Bind");
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Quote Failed");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Before Bind");
		Assert.assertTrue(false);
         
	}
}

public static void PolicyTitleShouldBeAfterPurchasing(WebDriver driver , String expTitle, ExtentReports report, ExtentTest t1) throws IOException{
	String s1=driver.findElement(By.xpath(PropertyReader.getElementLocator("Successfully_Quote"))).getText();
	System.out.println(s1);
	if(s1.trim().equalsIgnoreCase(expTitle))
	{
		t1.log(LogStatus.PASS, "Quote successfully created");
	    report.endTest(t1);
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Logged Failed");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Unable to create quote");
		Assert.assertTrue(false);
         
	}
}

public static void PolicyTitleShouldBeAfterPurchasingForRAC(WebDriver driver , String expTitle, ExtentReports report, ExtentTest t1) throws IOException{
	String s1=driver.findElement(By.xpath("//*[text()='Tax Invoice']")).getText();
	System.out.println(s1);
	if(s1.trim().equalsIgnoreCase(expTitle))
	{
		t1.log(LogStatus.PASS, "Quote successfully created");
	    report.endTest(t1);
		Assert.assertTrue(true);
		
	}
	else
	{
		t1.log(LogStatus.FAIL, "Unable to create quote with medical condition");
	    report.endTest(t1);
	    SnapShots.takeScreenshot(driver, "Unable to create quote");
		Assert.assertTrue(false);
         
	}
}

}



