package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import assertions.ValidationsCheck;
import base.Base_RAC;
import base.InitiateDriver;
import pom.CountryValidationCheck;

public class CountryValidation extends Base_RAC {
	
	@Test
	public void Validate_Country() throws IOException, InterruptedException {
		
		 ExtentTest t1 = report.startTest("Validation for country field");
		 CountryValidationCheck obj=new CountryValidationCheck(driver);
		 obj.CheckMessage();
		 ValidationsCheck.TravelMessageShouldBe(driver, "Please select the Travel Destination", report, t1);
	}

}
