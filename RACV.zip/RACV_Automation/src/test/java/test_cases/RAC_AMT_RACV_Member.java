package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import assertions.ValidatePage;
import base.Base_RAC;
import pom.RAC_AMT_WithRACV_Membership;

public class RAC_AMT_RACV_Member extends Base_RAC {
	
	@Test
	public void TC_0101() throws IOException {
		ExtentTest t1 = report.startTest("RAC AMT with RACV membership");
		
		RAC_AMT_WithRACV_Membership object=new RAC_AMT_WithRACV_Membership(driver);
		object.TC_1010();
		ValidatePage.PolicyTitleShouldBeAfterPurchasingForRAC(driver, "Tax Invoice", report, t1);
		
	}

}
