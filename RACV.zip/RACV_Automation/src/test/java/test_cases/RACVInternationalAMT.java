package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import assertions.Test_Case_Coverage;
import assertions.ValidatePage;
import base.InitiateDriver;
import pom.RACV_AMT_International;

public class RACVInternationalAMT extends InitiateDriver {
	
	@Test
	public void TC_018() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("RACV AMT International with medical condition");
	
	RACV_AMT_International object = new RACV_AMT_International(driver);
	object.TC_017();
	
	Test_Case_Coverage.Single_Trip_Annual_multi_trip(driver, report, t1);
	 Test_Case_Coverage.Get_an_Instant_Quote(driver, report, t1);
	 Test_Case_Coverage.Travel_Destination(driver, report, t1);
	 Test_Case_Coverage.Leaving_On(driver, report, t1);
	 Test_Case_Coverage.Returning_On(driver, report, t1);
	 Test_Case_Coverage.Age_of_Traveller_Primary(driver, report, t1);
	 Test_Case_Coverage.Age_of_Traveller_Secondary(driver, report, t1);
	 Test_Case_Coverage.Number_of_dependents(driver, report, t1);
	 Test_Case_Coverage.RACV_Membership_Entry_Box_Dropdown_Box(driver, report, t1);
	 Test_Case_Coverage.Disclaimer_text(driver, report, t1);
	 Test_Case_Coverage.Choose_your_excess(driver, report, t1);
	 Test_Case_Coverage.Going_on_a_cruise(driver, report, t1);
	 Test_Case_Coverage.Ski_Winter_Sports(driver, report, t1);
	 Test_Case_Coverage.Coverage_1_and_its_equivalent_limit(driver, report, t1);
	 Test_Case_Coverage.Coverage_2_and_its_equivalent_limit(driver, report, t1);
	 Test_Case_Coverage.Coverage_3_and_its_equivalent_limit(driver, report, t1);
   Test_Case_Coverage.Show_All_Benefits(driver, report, t1);
   Test_Case_Coverage.Quote_Summary_in_Header_Section(driver, report, t1);
   Test_Case_Coverage.Edit_button_in_Summary_Section_and_to_the_Right_of_Quote_Summary(driver, report, t1);
   Test_Case_Coverage.Continue_Button_in_Summary_Section(driver, report, t1);
   Test_Case_Coverage.First_Name_Primary_Traveler_in_Traveler_Details_Section(driver, report, t1);
   Test_Case_Coverage.Last_name_Primary_Traveler(driver, report, t1);
   Test_Case_Coverage.Date_of_Birth_Primary_Traveler(driver, report, t1);
   Test_Case_Coverage.First_Name_Secondary_Traveler(driver, report, t1);
   Test_Case_Coverage.Last_Name_Secondary_Traveler(driver, report, t1);
   Test_Case_Coverage.Street_Address_Primary_Traveler(driver, report, t1);
   Test_Case_Coverage.Suburb(driver, report, t1);
   Test_Case_Coverage.Suburb(driver, report, t1);
   Test_Case_Coverage.Street_Address_Primary_Traveler(driver, report, t1);
   Test_Case_Coverage.Postal_Code(driver, report, t1);
   Test_Case_Coverage.Email_Address(driver, report, t1);
   Test_Case_Coverage.Confirm_Email_Address(driver, report, t1);
   Test_Case_Coverage.Phone_number(driver, report, t1);
   Test_Case_Coverage.Dependent1_First_name(driver, report, t1);
   Test_Case_Coverage.Dependent1_Last_name(driver, report, t1);
   Test_Case_Coverage.Dependent1_DOB(driver, report, t1);
   Test_Case_Coverage.Remove_button_in_dependent_details_section(driver, report, t1);
   Test_Case_Coverage.Confirm_your_details_Button(driver, report, t1);
   Test_Case_Coverage.Confirmation_Finalise_Quote_button(driver, report, t1);
	 
	 Test_Case_Coverage.Traveler_details_with_pre_medical_conditions(driver, report, t1);
	 Test_Case_Coverage.Verify_that_user_select_only_one_selection_box_Yes_No(driver, report, t1);
	 Test_Case_Coverage.Continue_button_below_Pre_existing_medical_check_section(driver, report, t1);
	 Test_Case_Coverage.Assess_button_on_the_right_side_to_Selection_box_against_each_traveller(driver, report, t1);
	 Test_Case_Coverage.Validate_selection_box_with_Yes_No_option_for_assessment_question_1_Person_travelling_against_medical_advice(driver, report, t1);
	 Test_Case_Coverage.Continue(driver, report, t1);
	 Test_Case_Coverage.Disclaimer_with_Yes_No_button(driver, report, t1);
	 Test_Case_Coverage.Marketing_Content_hyperlink_in_Marketing_Section_with_Yes_No_button(driver, report, t1);
	 Test_Case_Coverage.Confirm_and_Pay_button(driver, report, t1);
	 Test_Case_Coverage.Cancel(driver, report, t1);
	 ValidatePage.PolicyTitleShouldBeAfterPurchasing(driver, "Thank you for purchasing RACV Travel Insurance", report, t1);
		
		
	}

}
