package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import base.Base_RAC;
import base.InitiateDriver;
import pom.Test_Cases_Details_Page;

public class Details_Page_Cases extends InitiateDriver {
	
	@Test
	public void T_18() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-18: Validate if user leave the primary name field as blank" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.pri_name();
		
		t1.log(LogStatus.PASS, "Validate primary first name field");
		report.endTest(t1);
	}

	@Test(priority=1)
	public void T_19() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-19: Validate if user enter wrong date of birth" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.DOB_Name();
		
		t1.log(LogStatus.PASS, "Validate DOB field");
		report.endTest(t1);
	}

	@Test(priority=2)
	public void T_20() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-20: Validate if user enter wrong format of date of birth" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.DOB_WrongFormat();
		
		t1.log(LogStatus.PASS, "Validate wrong format of DOB field");
		report.endTest(t1);
	}
	
	@Test(priority=3)
	public void T_21() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-21: Validate if user leave secondry first name as blank" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.Secondry_FName();
		
		t1.log(LogStatus.PASS, "Validate Secondry first name");
		report.endTest(t1);
	}
	
	@Test(priority=4)
	public void T_22() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-22: Validate if user leave address field as blank" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.Validate_Address();
		
		t1.log(LogStatus.PASS, "Validate Address field");
		report.endTest(t1);
	}
	
	@Test(priority=5)
	public void T_23() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-23: Validate if user leave Subrb field as blank" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.Validate_Subrb();
		
		t1.log(LogStatus.PASS, "Validate Subrb field");
		report.endTest(t1);
	}
	
	@Test(priority=6)
	public void T_24() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-24: Validate if user leave PostCode field as blank" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.validate_postcode();
		
		t1.log(LogStatus.PASS, "Validate PostCode field");
		report.endTest(t1);
	}
	
	@Test(priority=7)
	public void T_25() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-25: Validate if user leave Email field as blank" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.validate_email();
		
		t1.log(LogStatus.PASS, "Validate Email field");
		report.endTest(t1);
	}
	
	@Test(priority=8)
	public void T_26() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-26: Validate if user leave Con_Email field as blank" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.validate_con_Email();
		
		t1.log(LogStatus.PASS, "Validate Con_Email field");
		report.endTest(t1);
	}
	
	@Test(priority=9)
	public void T_27() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-27: Validate if user enter different Con_Email" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.validate_Invalid_con_Email();
		
		t1.log(LogStatus.PASS, "Validate Con_Email with different email");
		report.endTest(t1);
	}
	
	@Test(priority=10)
	public void T_28() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-28: Validate user is able to delete dependents" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.validate_Delete_Dependent();
		
		t1.log(LogStatus.PASS, "Validate User is able to delete dependents");
		report.endTest(t1);
	}
	

	@Test(priority=11)
	public void T_29() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-29: Validate user is able to add dependents" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.Add_Dependents();
		
		t1.log(LogStatus.PASS, "Validate User is able to add dependents");
		report.endTest(t1);
	}
	
	@Test(priority=12)
	public void T_30() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-30: Validate if user is leave dependents first name as blank" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.Validate_Dep_Fname();
		
		t1.log(LogStatus.PASS, "Validate if user is leave dependents first name as blank");
		report.endTest(t1);
	}
	
	@Test(priority=13)
	public void T_31() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-31: Validate if user is leave dependents last name as blank" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.Validate_Dep_Lname();
		
		t1.log(LogStatus.PASS, "Validate if user is leave dependents last name as blank");
		report.endTest(t1);
	}
	
	@Test(priority=14)
	public void T_32() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-32: Validate if user is leave dependents DOB field as blank" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.Validate_Dep_DOB();
		
		t1.log(LogStatus.PASS, "Validate if user is leave dependents DOB field as blank");
		report.endTest(t1);
	}
	
	@Test(priority=15)
	public void T_33() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-33: Validate if user is leave RACV membership number field as blank" );
		
		Test_Cases_Details_Page object=new Test_Cases_Details_Page(driver);
		object.validate_RACV_Field();
		
		t1.log(LogStatus.PASS, "Validate if user is leave RACV membership number field as blank");
		report.endTest(t1);
	}

}
