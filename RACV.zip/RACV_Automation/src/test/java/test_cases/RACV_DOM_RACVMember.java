package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import assertions.ValidatePage;
import base.InitiateDriver;
import pom.RACV_DomesticWithRACV_Member;

public class RACV_DOM_RACVMember extends InitiateDriver {
	
	@Test
	public void TC_0012() throws IOException {
		
		ExtentTest t1 = report.startTest("RACV AMT With RACV Member");
		
		RACV_DomesticWithRACV_Member object=new RACV_DomesticWithRACV_Member(driver);
		object.RACV_Member();
		ValidatePage.PolicyTitleShouldBeAfterPurchasing(driver, "Thank you for purchasing RACV Travel Insurance", report, t1);
	}

}
