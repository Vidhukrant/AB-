package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import assertions.ValidationsCheck;
import base.Base_RAC;
import base.InitiateDriver;
import pom.Test_Cases;

public class TestCases_Call extends InitiateDriver {
	
	@Test
	public void T1() throws IOException {
		
		ExtentTest t1 = report.startTest("TC-01: Validate \"Single Trip/Annual multi-trip\" Selection box in quote section  below header and it should overlay on the Background Image in the center");
		
		Test_Cases object=new Test_Cases(driver);
		object.AMT_Box();
		t1.log(LogStatus.PASS, "Successfully clicked");
		report.endTest(t1);
		
		
	}
	
	@Test(priority=1)
	public void T2() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-02: Validate user is should not enter date more than 60 days from selection date");
		Test_Cases object=new Test_Cases(driver);
		object.AMT_date_range();
		ValidationsCheck.AMT_MoreThan60_Days(driver, "Returning on date must be less than or equal to 60 days from Leaving On date.", report, t1);
		t1.log(LogStatus.PASS, "User is not able to proceed with more than 60 days");
		report.endTest(t1);
		
	}
	
	@Test(priority=2)
	public void T3() throws IOException {
		
		ExtentTest t1 = report.startTest("TC-03: Validate \"Travel Destination\" Entry Box/Dropdown list in Quote Section at RACV Homepage");
		
		Test_Cases object=new Test_Cases(driver);
		object.Country_Field();
		t1.log(LogStatus.PASS, "Country appear in list according to text enter");
		report.endTest(t1);
	}
	
	@Test(priority=3)
	public void T4() throws IOException {
		
		ExtentTest t1 = report.startTest("TC-04: Verify that user is able to select multiple Travel Destination");
		Test_Cases object=new Test_Cases(driver);
		object.Multiple_Countries();
		t1.log(LogStatus.PASS, "Multiple Country appear in list according to text enter");
		report.endTest(t1);
		
	}
	
	@Test(priority=4)
	public void T5() throws IOException {
		
		ExtentTest t1 = report.startTest("TC-05: Verify that user is able to remove selected country");
		Test_Cases object=new Test_Cases(driver);
		object.Remove_Countries();
		
		t1.log(LogStatus.PASS, "User is able to remove country successfully");
		report.endTest(t1);
		
	}
	
	@Test(priority=5)
	public void T6() throws IOException {
		
		ExtentTest t1 = report.startTest("TC-06: Verify that if user select the destination field, and/ or typing then a dropdown will appear with each region and the most popular destinations under each region");
		Test_Cases object=new Test_Cases(driver);
		object.ListOfCountries();
		
		t1.log(LogStatus.PASS, "Countries appear in list");
		report.endTest(t1);
		
	}
	
	@Test(priority=6)
	public void T7() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-07: User selects any of the Travel destinations that are listed as \"Do Not Travel\"  and continue to generate a quote.");
		Test_Cases object=new Test_Cases(driver);
		
		object.DoNotTravel();
		ValidationsCheck.Do_Not_Travel(driver, "Your destination currently has a travel alert, please click here to view the Alert.", report, t1);
		t1.log(LogStatus.PASS, "Travel message appeared for Do not travel country");
		report.endTest(t1);
		
	}
	
	@Test(priority=7)
	public void T8() throws IOException, InterruptedException {
		ExtentTest t1 = report.startTest("TC-08: Verify AMT  where age is <= 75");
		Test_Cases object=new Test_Cases(driver);
		object.Validate_AgeForAMT();
		ValidationsCheck.AMT_Age_MoreThan76(driver, "Travellers age must be less than or equal to 75.", report, t1);
		t1.log(LogStatus.PASS, "Age validation for AMT trip");
		report.endTest(t1);
		
	}
	@Test(priority=8)
	public void T9() throws IOException, InterruptedException {
		ExtentTest t1 = report.startTest("TC-09: Verify AMT  where age is < 18");
		Test_Cases object=new Test_Cases(driver);
		object.Validate_AgeForAMTLessThan18();
		ValidationsCheck.AMT_Age_MoreThan76(driver, "Travellers age must be less than or equal to 75.", report, t1);
		t1.log(LogStatus.PASS, "Age validation for AMT trip");
		report.endTest(t1);
		
	}

	@Test(priority=9)
	public void T10() throws IOException, InterruptedException {
		ExtentTest t1 = report.startTest("TC-10: Validate No. of dependents in quote Section" );
		Test_Cases object=new Test_Cases(driver);
		object.Validate_Dependent();
		
		t1.log(LogStatus.PASS, "No. of dependent validate");
		report.endTest(t1);
		
	}
	
	@Test(priority=10)
	public void T11() throws IOException, InterruptedException {
		ExtentTest t1 = report.startTest("TC-11: Validate No. of dependents in quote Section" );
		Test_Cases object=new Test_Cases(driver);
		object.State_Validate();
		
		t1.log(LogStatus.PASS, "State validate");
		report.endTest(t1);
		
	}
	
	@Test(priority=11)
	public void T12() throws IOException, InterruptedException {
		ExtentTest t1 = report.startTest("TC-12: Single and then AMT trip validation" );
		Test_Cases object=new Test_Cases(driver);
		object.SingleThanAMTTrip();
		
		t1.log(LogStatus.PASS, "SingleThanAMTTrip");
		report.endTest(t1);
		
	}
	
	@Test(priority=12)
	public void T13() throws IOException, InterruptedException {
		ExtentTest t1 = report.startTest("TC-13: Single trip date and then AMT trip validation" );
		Test_Cases object=new Test_Cases(driver);
		object.SingleTripDate();
		
		t1.log(LogStatus.PASS, "SingleTripDate");
		report.endTest(t1);
		
	}
	
	@Test(priority=13)
	public void T14() throws IOException, InterruptedException {
		ExtentTest t1 = report.startTest("TC-14: Validate Single Trip Annual Multi-trip selection box  below the Compare Travel Insurance at RACV coverage option page" );
		Test_Cases object=new Test_Cases(driver);
		object.Coverage_Check();
		
		t1.log(LogStatus.PASS, "Validate coverage");
		report.endTest(t1);
		
}
	
	@Test(priority=14)
	public void T15() throws IOException, InterruptedException {
		ExtentTest t1 = report.startTest("TC-15: Validate Edit option on coverage page" );
		Test_Cases object=new Test_Cases(driver);
		object.ValidateEditOption();
		
		t1.log(LogStatus.PASS, "Validate edit option on coverage page");
		report.endTest(t1);
		
}
	
	@Test(priority=15)
	public void T16() throws IOException, InterruptedException {
		ExtentTest t1 = report.startTest("TC-16: Validate Edit option on coverage page" );
		Test_Cases object=new Test_Cases(driver);
		object.ShowAllBenefit();
		
		t1.log(LogStatus.PASS, "Display benefits");
		report.endTest(t1);
		
}
	
	@Test(priority=16)
	public void T17() throws IOException, InterruptedException {
		ExtentTest t1 = report.startTest("TC-17: Validate Edit option on coverage page" );
		Test_Cases object=new Test_Cases(driver);
		object.Choose_Excess();
		
		t1.log(LogStatus.PASS, "Validate Choose Excess");
		report.endTest(t1);
		
}
}