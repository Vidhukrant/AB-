package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import assertions.ValidationsCheck;
import base.Base_RAC;
import base.InitiateDriver;
import pom.AMT_WithMoreThan_60;

public class RACV_AMT_MoreThan60Days extends Base_RAC {
	
	@Test
	public void TC_20() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("AMT with more than 60 days");
		AMT_WithMoreThan_60 object=new AMT_WithMoreThan_60(driver);
		
		object.check_date_range();
		ValidationsCheck.AMT_MoreThan60_Days(driver, "Returning on date must be less than or equal to 60 days from Leaving On date.", report, t1);
		
	}

}
