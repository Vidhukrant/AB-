package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import assertions.ValidationsCheck;
import base.Base_RAC;
import base.InitiateDriver;
import pom.CheckValidationWithDomesticAndInternational;
import pom.CountryValidationCheck;

public class DestinationField extends Base_RAC{
	
	@Test
	public  void tc_002() throws InterruptedException, IOException {
		 ExtentTest t1 = report.startTest("Destination Field Validation");
		 CheckValidationWithDomesticAndInternational test=new CheckValidationWithDomesticAndInternational(driver);
		 test.checkmessages();
		 ValidationsCheck.WarningMessageWithDomesticAndInternationalShouldBe(driver, "Cannot select Domestic( AUSTRALIA,LORD HOWE ISLAND,NORFOLK ISLAND ) and International (Other than AUSTRALIA,LORD HOWE ISLAND,NORFOLK ISLAND ) Travel Destinations at the same time.", report, t1);
		
	}
	
	@Test(priority=1)
	public void tcase3() throws IOException, InterruptedException {
		ExtentTest t1 = report.startTest("Validate if user leave destination field as blank");
		
		CountryValidationCheck obj=new CountryValidationCheck(driver);
		 obj.CheckMessage();
		 ValidationsCheck.TravelMessageShouldBe(driver, "Please select the Travel Destination", report, t1);
		
	}

}
