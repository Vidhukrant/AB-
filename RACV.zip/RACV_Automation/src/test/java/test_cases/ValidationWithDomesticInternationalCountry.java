package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import assertions.ValidationsCheck;
import base.Base_RAC;
import base.InitiateDriver;
import pom.CheckValidationWithDomesticAndInternational;

public class ValidationWithDomesticInternationalCountry extends Base_RAC {
	
	@Test
	public void validation_domestic_international() throws InterruptedException, IOException {
		
		ExtentTest t1 = report.startTest("Validation for Domestic and International country field");
		
		 CheckValidationWithDomesticAndInternational test=new CheckValidationWithDomesticAndInternational(driver);
		 test.checkmessages();
		 ValidationsCheck.WarningMessageWithDomesticAndInternationalShouldBe(driver, "Cannot select Domestic( AUSTRALIA,LORD HOWE ISLAND,NORFOLK ISLAND ) and International (Other than AUSTRALIA,LORD HOWE ISLAND,NORFOLK ISLAND ) Travel Destinations at the same time.", report, t1);
		
		
		
		
	}

}
