package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import assertions.ValidatePage;
import base.InitiateDriver;
import pom.RACV_WithMulCountry_WithRACV_Member;
import pom.RAC_AMT_WM;

public class RACV_MulCountry_WithRACVMembership extends InitiateDriver{
	
	@Test
	public void TC_100() throws IOException {
		
		ExtentTest t1 = report.startTest("RACV AMT With multiple country with RACV membership");
		RACV_WithMulCountry_WithRACV_Member object=new RACV_WithMulCountry_WithRACV_Member(driver);
		object.RACV_WithMulCountry();
		ValidatePage.PolicyTitleShouldBeAfterPurchasing(driver, "Thank you for purchasing RACV Travel Insurance", report, t1);
		
		
	}

}
