package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import assertions.ValidatePage;
import base.InitiateDriver;
import pom.RACV_AMT_Without_Medical;

public class RACV_Without_Medical extends InitiateDriver {
	
	@Test
	public void TC_011() throws IOException {
		
		ExtentTest t1 = report.startTest("RACV AMT without medical condition");
		
		RACV_AMT_Without_Medical object=new RACV_AMT_Without_Medical(driver);
		
		object.AMT_Flow();
		ValidatePage.PolicyTitleShouldBeAfterPurchasing(driver, "Thank you for purchasing RACV Travel Insurance", report, t1);
	}   

}
