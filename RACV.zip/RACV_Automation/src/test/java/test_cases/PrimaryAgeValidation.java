package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import assertions.ValidationsCheck;
import base.Base_RAC;
import base.InitiateDriver;
import pom.PrimaryAdult;
import pom.PrimaryAgeWithLessThan18yr;
import pom.PrimaryAgeWithMoreThan110yr;

public class PrimaryAgeValidation extends Base_RAC {
	     @Test
	     public  void Primary_Age() throws InterruptedException, IOException {
		 ExtentTest t1 = report.startTest("TC-001: Primary Age Validation");
		 PrimaryAdult object=new PrimaryAdult(driver);
		 object.CheckPrimaryAge();
		 ValidationsCheck.PrimaryAgeValidation(driver, "Please enter the age of the Primary Traveller", report, t1);
		 
		 

}
	     
	   @Test(priority=1)
	     public  void Primary_Age_Below18() throws InterruptedException, IOException {
		 ExtentTest t1 = report.startTest("TC-002: Primary Age Below 18 yr Validation");
		 PrimaryAgeWithLessThan18yr ob=new PrimaryAgeWithLessThan18yr(driver);
		 ob.Check_Primary_Age_Below18();
		 ValidationsCheck.PrimaryAgeBelow18(driver, "Age of Traveller must be between 18-110", report, t1);
		 ValidationsCheck.StateValidation(driver, "Please select the State you reside in", report, t1);
		 
	    }
	    
	    @Test(priority=2)
	    public  void Primary_Age_MoreThan110() throws InterruptedException, IOException {

	    	
	   		 ExtentTest t1 = report.startTest("TC-003: Primary Age More Than 110 yr Validation");
	   		PrimaryAgeWithMoreThan110yr ob1=new PrimaryAgeWithMoreThan110yr(driver);
	   		 ob1.CheckAgeWithMoreThan110yr();
	   		 ValidationsCheck.PrimaryAgeBelow18(driver, "Age of Traveller must be between 18-110", report, t1);
}}
