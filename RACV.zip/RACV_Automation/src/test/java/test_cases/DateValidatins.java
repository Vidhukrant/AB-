package test_cases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import assertions.Test_Case_Coverage;
import assertions.ValidationsCheck;
import base.Base_RAC;
import base.InitiateDriver;
import pom.DateValidationWithBlank;
import pom.DateValidationWithMoreThan548Days;
import pom.DateValidationWithPastDate;

public class DateValidatins extends Base_RAC {
	
	
	
	@Test
	public void TC_04() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-004: Validation for blank travel date");
		
		DateValidationWithBlank object=new DateValidationWithBlank(driver);
		object.CheckValidations();
		ValidationsCheck.BlankLeavingDate(driver, "Please select the Leaving On date", report, t1);
		ValidationsCheck.BlankReturnDate(driver, "Please select the Returning on date", report, t1);
		
		
		
	}
	
	@Test(priority=1)
	public void TC_05() throws IOException, InterruptedException {
		
		ExtentTest t1 = report.startTest("TC-005: Past date validation");
		DateValidationWithPastDate obj=new DateValidationWithPastDate(driver);
		obj.PastDate();
		ValidationsCheck.PastTravelDate(driver, "Leaving On date cannot be date before current date", report, t1);
		
	}
	
	@Test(priority=2)
	public void TC_06() throws IOException, InterruptedException {
		ExtentTest t1 = report.startTest("TC-006: Validation for more than 548 days");
		DateValidationWithMoreThan548Days obj=new DateValidationWithMoreThan548Days(driver);
		obj.CheckDateWith548Days();
		ValidationsCheck.FutureDateWithMoreThan548Days(driver, "Leaving Date can not greater than 548 days.", report, t1);
	}
}
