package utility;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class PropertyReader {
	
	public static String getProjectConfiguration(String PropName) throws IOException
	{
		File f = new File("./Configuration_File/ProjectConfiguration.properties");
		FileReader fr = new FileReader(f);
		Properties prop = new Properties();
		prop.load(fr);
		return (String) prop.get(PropName);
	}
	
	
	public static String getElementLocator(String PropName) throws IOException
	{
		File f = new File("./Configuration_File/Elements.properties");
		FileReader fr = new FileReader(f);
		Properties prop = new Properties();
		prop.load(fr);
		return (String) prop.get(PropName);
	}
	
	public static String getElementLocator2(String PropName) throws IOException
	{
		File f = new File("./Configuration_File/ElementLocators.properties");
		FileReader fr = new FileReader(f);
		Properties prop = new Properties();
		prop.load(fr);
		return (String) prop.get(PropName);
	}
	
	public static String getValidationMessage(String PropName) throws IOException
	{
		File f = new File("./Configuration_File/Validation_Message.properties");
		FileReader fr = new FileReader(f);
		Properties prop = new Properties();
		prop.load(fr);
		return (String) prop.get(PropName);
	}

}
