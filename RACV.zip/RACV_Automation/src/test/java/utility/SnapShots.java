package utility;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class SnapShots {
	
public static void takeScreenshot(WebDriver driver, String name) throws IOException{
		
		TakesScreenshot scr = (TakesScreenshot)driver;
		File f = scr.getScreenshotAs(OutputType.FILE);
		File f1 = new File("./Snapshot/" + name+ ".png");
		FileUtils.copyFile(f, f1);
	}
	

}
