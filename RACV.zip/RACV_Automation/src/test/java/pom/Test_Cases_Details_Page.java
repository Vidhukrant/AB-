package pom;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import utility.PropertyReader;
import utility.SnapShots;

public class Test_Cases_Details_Page {
	
	WebDriver driver=null;
	
	public Test_Cases_Details_Page(WebDriver driver) {
		
		this.driver=driver;
	}
	
	public void Common() throws IOException {
		
try {
			
			
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			JavascriptExecutor js=(JavascriptExecutor) driver;
			WebElement ele=driver.findElement(By.id("country"));
			
			//js.executeScript("arguments[0].scrollIntoView();", ele);
			js.executeScript("window.scrollBy(0,400)");
			Thread.sleep(6000);
			WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator2("Country")));
			contry.click();
			Thread.sleep(2000);
			contry.sendKeys(PropertyReader.getElementLocator2("Country_Name"));
			
			Thread.sleep(2000);
			WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator2("Country_click")));
			Con_Click.click();
			
			WebElement Date=driver.findElement(By.id(PropertyReader.getElementLocator2("Travel_Date")));
			
			Thread.sleep(2000);
			Date.sendKeys(PropertyReader.getElementLocator2("Date"));
					
			Actions act=new Actions(driver);
			act.click();
			
			WebElement F_Age=driver.findElement(By.id(PropertyReader.getElementLocator2("Age_First")));
			F_Age.sendKeys(PropertyReader.getElementLocator2("Age1"));
			Thread.sleep(2000);
			WebElement state_click=driver.findElement(By.xpath(PropertyReader.getElementLocator2("State")));
			state_click.click();
			
			Thread.sleep(2000);
			WebElement state=driver.findElement(By.xpath(PropertyReader.getElementLocator2("State_Choose")));
			state.click();
			Thread.sleep(2000);
			
			WebElement RACV=driver.findElement(By.xpath(PropertyReader.getElementLocator2("RACV")));
			RACV.click();
			Thread.sleep(2000);
			WebElement RACV_Mem= driver.findElement(By.xpath(PropertyReader.getElementLocator2("RACV_Member")));
			RACV_Mem.click();
			Thread.sleep(2000);
			WebElement Get_Quote=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Get_Quote")));
			Get_Quote.click();
			
			Thread.sleep(3000);
			js.executeScript("window.scrollBy(0,700)");
			Thread.sleep(60000);
			WebElement conti=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Continue")));
			conti.click();
	}

catch (Exception e) {
	SnapShots.takeScreenshot(driver, "Test_Cases_Details_Page class");
}

}
	public void pri_name() throws IOException, InterruptedException {
		
		this.Common();
		
		Thread.sleep(3000);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,300)");
		
		Thread.sleep(1000);
		WebElement Pname=driver.findElement(By.id(PropertyReader.getElementLocator2("First_Name")));
		Pname.click();
		
		Thread.sleep(1000);
		WebElement Lname=driver.findElement(By.id(PropertyReader.getElementLocator2("Last_Name")));
		Lname.sendKeys(PropertyReader.getElementLocator2("Lfirst"));
}
	public void DOB_Name() throws IOException, InterruptedException {
		
		this.Common();
		Thread.sleep(3000);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,300)");
		
		Thread.sleep(1000);
		WebElement Pname=driver.findElement(By.id(PropertyReader.getElementLocator2("First_Name")));
		Pname.sendKeys("Leah");
		
		Thread.sleep(1000);
		WebElement DOB=driver.findElement(By.id(PropertyReader.getElementLocator2("Primary_DOB")));
		DOB.sendKeys("02/01/2011");


	}
	
public void DOB_WrongFormat() throws IOException, InterruptedException {
		
		this.Common();
		Thread.sleep(3000);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,300)");
		
		Thread.sleep(1000);
		WebElement Pname=driver.findElement(By.id(PropertyReader.getElementLocator2("First_Name")));
		Pname.sendKeys("Leah");
		
		Thread.sleep(1000);
		WebElement DOB=driver.findElement(By.id(PropertyReader.getElementLocator2("Primary_DOB")));
		DOB.sendKeys("2011/01/02");
		
		Thread.sleep(1000);
		Pname.click();


	}
	

public void WithDependent() throws IOException {
	
	try {
		
		
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		
		
		Thread.sleep(3000);
		WebElement ele=driver.findElement(By.id("country"));
		
		//js.executeScript("arguments[0].scrollIntoView();", ele);
		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(6000);
		WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator("Country")));
		contry.click();
		Thread.sleep(2000);
		contry.sendKeys(PropertyReader.getElementLocator("Domestic"));
		
		Thread.sleep(2000);
		WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator("Country_click")));
		Con_Click.click();
		
		WebElement Date=driver.findElement(By.id(PropertyReader.getElementLocator("Travel_Date")));
		
		Thread.sleep(2000);
		Date.sendKeys(PropertyReader.getElementLocator("Date"));
				
		Actions act=new Actions(driver);
		act.click();
		
		WebElement F_Age=driver.findElement(By.id(PropertyReader.getElementLocator("Age_First")));
		F_Age.sendKeys(PropertyReader.getElementLocator("Age1"));
		
		Thread.sleep(2000);
		WebElement AgeSecondry=driver.findElement(By.xpath(PropertyReader.getElementLocator("AgeSecondry")));
		AgeSecondry.sendKeys(PropertyReader.getElementLocator("Age2"));
		
		WebElement Dependents=driver.findElement(By.xpath(PropertyReader.getElementLocator("Dependents")));
		Dependents.sendKeys(PropertyReader.getElementLocator("Dep_No"));
		Thread.sleep(2000);
		WebElement state_click=driver.findElement(By.xpath(PropertyReader.getElementLocator("State")));
		state_click.click();
		
		Thread.sleep(2000);
		WebElement state=driver.findElement(By.xpath(PropertyReader.getElementLocator("State_Choose")));
		state.click();
		Thread.sleep(2000);
		
		WebElement RACV=driver.findElement(By.xpath(PropertyReader.getElementLocator("RACV")));
		RACV.click();
		Thread.sleep(2000);
		WebElement RACV_Mem= driver.findElement(By.xpath(PropertyReader.getElementLocator("RACV_Member")));
		RACV_Mem.click();
		Thread.sleep(2000);
		WebElement Get_Quote=driver.findElement(By.xpath(PropertyReader.getElementLocator("Get_Quote")));
		Get_Quote.click();
		
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,700)");
		Thread.sleep(50000);
		WebElement conti=driver.findElement(By.xpath(PropertyReader.getElementLocator("Continue")));
		conti.click();
		js.executeScript("window.scrollBy(0,300)");
		
		Thread.sleep(1000);
		WebElement Pname=driver.findElement(By.id(PropertyReader.getElementLocator("First_Name")));
		Pname.sendKeys(PropertyReader.getElementLocator("Pfirst"));
		
		Thread.sleep(1000);
		WebElement Lname=driver.findElement(By.id(PropertyReader.getElementLocator("Last_Name")));
		Lname.sendKeys(PropertyReader.getElementLocator("Lfirst"));
		
		Thread.sleep(1000);
		WebElement DOB=driver.findElement(By.id(PropertyReader.getElementLocator("Primary_DOB")));
		DOB.sendKeys(PropertyReader.getElementLocator("DOB"));
		
}
	catch (Exception e) {
		SnapShots.takeScreenshot(driver, "Test_Cases_Details_Page class");
	}
}

public void Secondry_FName() throws IOException, InterruptedException {
	
	this.WithDependent();
	Thread.sleep(1000);
	WebElement SecondryFname=driver.findElement(By.xpath(PropertyReader.getElementLocator("SecondryFname")));
	SecondryFname.click();
	Thread.sleep(1000);
	WebElement SecondryLname=driver.findElement(By.xpath(PropertyReader.getElementLocator("SecondryLname")));
	SecondryLname.sendKeys(PropertyReader.getElementLocator("SecLname"));
}

public void Validate_Address() throws IOException, InterruptedException {
	
	this.Common();
	
	Thread.sleep(3000);
	JavascriptExecutor js=(JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,300)");
	
	Thread.sleep(1000);
	WebElement Pname=driver.findElement(By.id(PropertyReader.getElementLocator2("First_Name")));
	Pname.sendKeys("John");
	
	Thread.sleep(1000);
	WebElement Lname=driver.findElement(By.id(PropertyReader.getElementLocator2("Last_Name")));
	Lname.sendKeys(PropertyReader.getElementLocator2("Lfirst"));
	
	//Thread.sleep(1000);
	Thread.sleep(1000);
	WebElement DOB=driver.findElement(By.id(PropertyReader.getElementLocator("Primary_DOB")));
	DOB.sendKeys(PropertyReader.getElementLocator("DOB"));
	
	Thread.sleep(1000);
	WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator2("Address")));
	address.click();
	
	Thread.sleep(3000);
	WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Suburb")));
	sub.sendKeys(PropertyReader.getElementLocator2("sub"));
	
}

public void Validate_Subrb() throws IOException, InterruptedException {
	
	this.Common();
	
	Thread.sleep(3000);
	JavascriptExecutor js=(JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,300)");
	
	Thread.sleep(1000);
	WebElement Pname=driver.findElement(By.id(PropertyReader.getElementLocator2("First_Name")));
	Pname.sendKeys("John");
	
	Thread.sleep(1000);
	WebElement Lname=driver.findElement(By.id(PropertyReader.getElementLocator2("Last_Name")));
	Lname.sendKeys(PropertyReader.getElementLocator2("Lfirst"));
	
	//Thread.sleep(1000);
	Thread.sleep(1000);
	WebElement DOB=driver.findElement(By.id(PropertyReader.getElementLocator("Primary_DOB")));
	DOB.sendKeys(PropertyReader.getElementLocator("DOB"));
	
	Thread.sleep(3000);
	WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Suburb")));
	sub.click();
	
	
	Thread.sleep(1000);
	WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator2("Address")));
	address.sendKeys("Address one");
	
	
}

public void validate_postcode() throws IOException, InterruptedException {
	
	this.WithDependent();
	
	Thread.sleep(1000);
	WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator2("Address")));
	address.sendKeys("Address one");
	
	Thread.sleep(3000);
	WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Suburb")));
	sub.sendKeys(PropertyReader.getElementLocator2("sub"));
	
	Thread.sleep(1000);
	WebElement Post=driver.findElement(By.id(PropertyReader.getElementLocator("Post_Code")));
	Post.click();
	
	Thread.sleep(1000);
	WebElement email=driver.findElement(By.id(PropertyReader.getElementLocator("Email")));
	email.sendKeys(PropertyReader.getElementLocator("E_address"));
}

public void validate_email() throws IOException, InterruptedException {
	
	this.WithDependent();
	
	Thread.sleep(1000);
	WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator2("Address")));
	address.sendKeys("Address one");
	
	Thread.sleep(3000);
	WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Suburb")));
	sub.sendKeys(PropertyReader.getElementLocator2("sub"));
	
	Thread.sleep(1000);
	WebElement Post=driver.findElement(By.id(PropertyReader.getElementLocator("Post_Code")));
	Post.sendKeys("5000");
	
	Thread.sleep(1000);
	WebElement email=driver.findElement(By.id(PropertyReader.getElementLocator("Email")));
	email.click();
	
	Thread.sleep(1000);
	WebElement con_email=driver.findElement(By.id(PropertyReader.getElementLocator("Con_Email")));
	con_email.sendKeys(PropertyReader.getElementLocator("con_address"));
}
public void validate_con_Email() throws IOException, InterruptedException {
	
this.WithDependent();
	
	Thread.sleep(1000);
	WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator2("Address")));
	address.sendKeys("Address one");
	
	Thread.sleep(3000);
	WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Suburb")));
	sub.sendKeys(PropertyReader.getElementLocator2("sub"));
	
	Thread.sleep(1000);
	WebElement Post=driver.findElement(By.id(PropertyReader.getElementLocator("Post_Code")));
	Post.sendKeys("5000");
	
	Thread.sleep(1000);
	WebElement email=driver.findElement(By.id(PropertyReader.getElementLocator("Email")));
	email.sendKeys(PropertyReader.getElementLocator("con_address"));
	
	Thread.sleep(1000);
	WebElement con_email=driver.findElement(By.id(PropertyReader.getElementLocator("Con_Email")));
	con_email.click();
	
	JavascriptExecutor js=(JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,100)");
	Thread.sleep(1000);
	
	WebElement Phone=driver.findElement(By.id(PropertyReader.getElementLocator("Phone")));
	Phone.sendKeys(PropertyReader.getElementLocator("number"));
	
	
}

public void validate_Invalid_con_Email() throws IOException, InterruptedException {
	
this.WithDependent();
	
	Thread.sleep(1000);
	WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator2("Address")));
	address.sendKeys("Address one");
	
	Thread.sleep(3000);
	WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Suburb")));
	sub.sendKeys(PropertyReader.getElementLocator2("sub"));
	
	Thread.sleep(1000);
	WebElement Post=driver.findElement(By.id(PropertyReader.getElementLocator("Post_Code")));
	Post.sendKeys("5000");
	
	Thread.sleep(1000);
	WebElement email=driver.findElement(By.id(PropertyReader.getElementLocator("Email")));
	email.sendKeys(PropertyReader.getElementLocator("con_address"));
	
	Thread.sleep(1000);
	WebElement con_email=driver.findElement(By.id(PropertyReader.getElementLocator("Con_Email")));
	con_email.sendKeys("Test1234@gmail.com");
	
	JavascriptExecutor js=(JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,100)");
	Thread.sleep(1000);
	WebElement Phone=driver.findElement(By.id(PropertyReader.getElementLocator("Phone")));
	Phone.sendKeys(PropertyReader.getElementLocator("number"));
	
}

public void validate_Delete_Dependent() throws IOException, InterruptedException {
	
this.WithDependent();
	
	Thread.sleep(1000);
	WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator2("Address")));
	address.sendKeys("Address one");
	
	Thread.sleep(3000);
	WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Suburb")));
	sub.sendKeys(PropertyReader.getElementLocator2("sub"));
	
	Thread.sleep(1000);
	WebElement Post=driver.findElement(By.id(PropertyReader.getElementLocator("Post_Code")));
	Post.sendKeys("5000");
	
	Thread.sleep(1000);
	WebElement email=driver.findElement(By.id(PropertyReader.getElementLocator("Email")));
	email.sendKeys(PropertyReader.getElementLocator("con_address"));
	
	Thread.sleep(1000);
	WebElement con_email=driver.findElement(By.id(PropertyReader.getElementLocator("Con_Email")));
	con_email.sendKeys(PropertyReader.getElementLocator("con_address"));
	
	JavascriptExecutor js=(JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,100)");
	Thread.sleep(1000);
	WebElement Phone=driver.findElement(By.id(PropertyReader.getElementLocator("Phone")));
	Phone.sendKeys(PropertyReader.getElementLocator("number"));
	
	js.executeScript("window.scrollBy(0,300)");
	
	Thread.sleep(2000);
	WebElement Delete_Dep=driver.findElement(By.xpath("//i[@class='fa fa-trash']"));
	Delete_Dep.click();
	
}

public void Add_Dependents() throws InterruptedException, IOException {
	
this.WithDependent();
	
	Thread.sleep(1000);
	WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator2("Address")));
	address.sendKeys("Address one");
	
	Thread.sleep(3000);
	WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Suburb")));
	sub.sendKeys(PropertyReader.getElementLocator2("sub"));
	
	Thread.sleep(1000);
	WebElement Post=driver.findElement(By.id(PropertyReader.getElementLocator("Post_Code")));
	Post.sendKeys("5000");
	
	Thread.sleep(1000);
	WebElement email=driver.findElement(By.id(PropertyReader.getElementLocator("Email")));
	email.sendKeys(PropertyReader.getElementLocator("con_address"));
	
	Thread.sleep(1000);
	WebElement con_email=driver.findElement(By.id(PropertyReader.getElementLocator("Con_Email")));
	con_email.sendKeys(PropertyReader.getElementLocator("con_address"));
	
	JavascriptExecutor js=(JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,100)");
	Thread.sleep(1000);
	WebElement Phone=driver.findElement(By.id(PropertyReader.getElementLocator("Phone")));
	Phone.sendKeys(PropertyReader.getElementLocator("number"));
	
	js.executeScript("window.scrollBy(0,300)");
	
	Thread.sleep(2000);
	WebElement Add_Dep=driver.findElement(By.xpath("//i[@class='fa fa-plus-circle pl-3']"));
	Add_Dep.click();
	
	
}

public void Validate_Dep_Fname() throws InterruptedException, IOException {
	
this.WithDependent();
	
	Thread.sleep(1000);
	WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator2("Address")));
	address.sendKeys("Address one");
	
	Thread.sleep(3000);
	WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Suburb")));
	sub.sendKeys(PropertyReader.getElementLocator2("sub"));
	
	Thread.sleep(1000);
	WebElement Post=driver.findElement(By.id(PropertyReader.getElementLocator("Post_Code")));
	Post.sendKeys("5000");
	
	Thread.sleep(1000);
	WebElement email=driver.findElement(By.id(PropertyReader.getElementLocator("Email")));
	email.sendKeys(PropertyReader.getElementLocator("con_address"));
	
	Thread.sleep(1000);
	WebElement con_email=driver.findElement(By.id(PropertyReader.getElementLocator("Con_Email")));
	con_email.sendKeys(PropertyReader.getElementLocator("con_address"));
	
	JavascriptExecutor js=(JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,100)");
	Thread.sleep(1000);
	WebElement Phone=driver.findElement(By.id(PropertyReader.getElementLocator("Phone")));
	Phone.sendKeys(PropertyReader.getElementLocator("number"));
	
	js.executeScript("window.scrollBy(0,300)");
	
	Thread.sleep(2000);
	Thread.sleep(2000);
	 WebElement DependentFname=driver.findElement(By.xpath(PropertyReader.getElementLocator("DependentFname")));
	 DependentFname.click();
	 Thread.sleep(1000);
	 WebElement DependentLname= driver.findElement(By.xpath(PropertyReader.getElementLocator("DependentLname")));
	 DependentLname.sendKeys(PropertyReader.getElementLocator("DepLname"));
	
	
	
}

public void Validate_Dep_Lname() throws IOException, InterruptedException {
	
this.WithDependent();
	
	Thread.sleep(1000);
	WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator2("Address")));
	address.sendKeys("Address one");
	
	Thread.sleep(3000);
	WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Suburb")));
	sub.sendKeys(PropertyReader.getElementLocator2("sub"));
	
	Thread.sleep(1000);
	WebElement Post=driver.findElement(By.id(PropertyReader.getElementLocator("Post_Code")));
	Post.sendKeys("5000");
	
	Thread.sleep(1000);
	WebElement email=driver.findElement(By.id(PropertyReader.getElementLocator("Email")));
	email.sendKeys(PropertyReader.getElementLocator("con_address"));
	
	Thread.sleep(1000);
	WebElement con_email=driver.findElement(By.id(PropertyReader.getElementLocator("Con_Email")));
	con_email.sendKeys(PropertyReader.getElementLocator("con_address"));
	
	JavascriptExecutor js=(JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,100)");
	Thread.sleep(1000);
	WebElement Phone=driver.findElement(By.id(PropertyReader.getElementLocator("Phone")));
	Phone.sendKeys(PropertyReader.getElementLocator("number"));
	
	js.executeScript("window.scrollBy(0,300)");
	
	Thread.sleep(2000);
	Thread.sleep(2000);
	 WebElement DependentFname=driver.findElement(By.xpath(PropertyReader.getElementLocator("DependentFname")));
	 DependentFname.sendKeys(PropertyReader.getElementLocator("DepFname"));
	 Thread.sleep(1000);
	 WebElement DependentLname= driver.findElement(By.xpath(PropertyReader.getElementLocator("DependentLname")));
	 DependentLname.click();
	 
	 Thread.sleep(1000);
	 WebElement DepDOB=driver.findElement(By.xpath(PropertyReader.getElementLocator("DepDOB")));
	 DepDOB.sendKeys(PropertyReader.getElementLocator("DDOB"));
}

public void Validate_Dep_DOB() throws IOException, InterruptedException {
	
this.WithDependent();
	
	Thread.sleep(1000);
	WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator2("Address")));
	address.sendKeys("Address one");
	
	Thread.sleep(3000);
	WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Suburb")));
	sub.sendKeys(PropertyReader.getElementLocator2("sub"));
	
	Thread.sleep(1000);
	WebElement Post=driver.findElement(By.id(PropertyReader.getElementLocator("Post_Code")));
	Post.sendKeys("5000");
	
	Thread.sleep(1000);
	WebElement email=driver.findElement(By.id(PropertyReader.getElementLocator("Email")));
	email.sendKeys(PropertyReader.getElementLocator("con_address"));
	
	Thread.sleep(1000);
	WebElement con_email=driver.findElement(By.id(PropertyReader.getElementLocator("Con_Email")));
	con_email.sendKeys(PropertyReader.getElementLocator("con_address"));
	
	JavascriptExecutor js=(JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,100)");
	Thread.sleep(1000);
	WebElement Phone=driver.findElement(By.id(PropertyReader.getElementLocator("Phone")));
	Phone.sendKeys(PropertyReader.getElementLocator("number"));
	
	js.executeScript("window.scrollBy(0,300)");
	
	Thread.sleep(2000);
	Thread.sleep(2000);
	 WebElement DependentFname=driver.findElement(By.xpath(PropertyReader.getElementLocator("DependentFname")));
	 DependentFname.sendKeys(PropertyReader.getElementLocator("DepFname"));
	 Thread.sleep(1000);
	 WebElement DependentLname= driver.findElement(By.xpath(PropertyReader.getElementLocator("DependentLname")));
	 DependentLname.click();
	 
	 Thread.sleep(1000);
	 WebElement DepDOB=driver.findElement(By.xpath(PropertyReader.getElementLocator("DepDOB")));
	 DepDOB.click();

	 Thread.sleep(1000);
	 
	 DependentLname.sendKeys(PropertyReader.getElementLocator("DepLname"));
}

public void validate_RACV_Field() throws InterruptedException, IOException {
	
	
		
		Thread.sleep(4000);
		WebElement AMT=driver.findElement(By.xpath("//*[text()='Annual Multi-Trip ']"));
		AMT.click();
		
		
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		
		
		Thread.sleep(3000);
		WebElement ele=driver.findElement(By.id("country"));
		
		//js.executeScript("arguments[0].scrollIntoView();", ele);
		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(6000);
		WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator("Country")));
		contry.click();
		Thread.sleep(2000);
		contry.sendKeys(PropertyReader.getElementLocator("Country_Name"));
		
		Thread.sleep(2000);
		WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator("Country_click")));
		Con_Click.click();
		
		Thread.sleep(1000);
		contry.click();
		
		Thread.sleep(1000);
		contry.sendKeys("Thailand");
		
		Thread.sleep(3000);
		WebElement Thailand=driver.findElement(By.xpath("//*[text()=' THAILAND ']"));
		Thailand.click();
		
		WebElement Date=driver.findElement(By.id(PropertyReader.getElementLocator("Travel_Date")));
		
		Thread.sleep(2000);
		Date.sendKeys(PropertyReader.getElementLocator("Date"));
		
		Thread.sleep(2000);
		WebElement Returndate=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Return_Date")));
		Thread.sleep(1000);
		Returndate.sendKeys("30/03/2020");
				
		Actions act=new Actions(driver);
		act.click();
		
		WebElement F_Age=driver.findElement(By.id(PropertyReader.getElementLocator("Age_First")));
		F_Age.sendKeys(PropertyReader.getElementLocator("Age1"));
		
		Thread.sleep(2000);
		WebElement AgeSecondry=driver.findElement(By.xpath(PropertyReader.getElementLocator("AgeSecondry")));
		AgeSecondry.sendKeys(PropertyReader.getElementLocator("Age2"));
		
		WebElement Dependents=driver.findElement(By.xpath(PropertyReader.getElementLocator("Dependents")));
		Dependents.sendKeys(PropertyReader.getElementLocator("Dep_No"));
		Thread.sleep(2000);
		WebElement state_click=driver.findElement(By.xpath(PropertyReader.getElementLocator("State")));
		state_click.click();
		
		Thread.sleep(2000);
		WebElement state=driver.findElement(By.xpath(PropertyReader.getElementLocator("State_Choose")));
		state.click();
		Thread.sleep(2000);
		
		/*WebElement RACV=driver.findElement(By.xpath(PropertyReader.getElementLocator("RACV")));
		RACV.click();
		Thread.sleep(2000);
		WebElement RACV_Mem= driver.findElement(By.xpath(PropertyReader.getElementLocator("RACV_Member")));
		RACV_Mem.click();
		Thread.sleep(2000);*/
		WebElement Get_Quote=driver.findElement(By.xpath(PropertyReader.getElementLocator("Get_Quote")));
		Get_Quote.click();
		
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,700)");
		Thread.sleep(60000);
		WebElement conti=driver.findElement(By.xpath(PropertyReader.getElementLocator("Continue")));
		conti.click();
		js.executeScript("window.scrollBy(0,300)");
		
		Thread.sleep(1000);
		WebElement Pname=driver.findElement(By.id(PropertyReader.getElementLocator("First_Name")));
		Pname.sendKeys(PropertyReader.getElementLocator("Pfirst"));
		
		Thread.sleep(1000);
		WebElement Lname=driver.findElement(By.id(PropertyReader.getElementLocator("Last_Name")));
		Lname.sendKeys(PropertyReader.getElementLocator("Lfirst"));
		
		Thread.sleep(1000);
		WebElement DOB=driver.findElement(By.id(PropertyReader.getElementLocator("Primary_DOB")));
		DOB.sendKeys(PropertyReader.getElementLocator("DOB"));
		
		
		
		Thread.sleep(1000);
		WebElement SecondryFname=driver.findElement(By.xpath(PropertyReader.getElementLocator("SecondryFname")));
		SecondryFname.sendKeys(PropertyReader.getElementLocator("SecFname"));
		Thread.sleep(1000);
		WebElement SecondryLname=driver.findElement(By.xpath(PropertyReader.getElementLocator("SecondryLname")));
		SecondryLname.sendKeys(PropertyReader.getElementLocator("SecLname"));
		Thread.sleep(1000);
		WebElement SecondryDOB= driver.findElement(By.xpath(PropertyReader.getElementLocator("SecondryDOB")));
		SecondryDOB.sendKeys(PropertyReader.getElementLocator("SecDOB"));
		
		Thread.sleep(1000);
		WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator("Address")));
		address.sendKeys(PropertyReader.getElementLocator("address"));
		
		Thread.sleep(3000);
		WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator("Suburb")));
		sub.sendKeys(PropertyReader.getElementLocator("sub"));
		
		Thread.sleep(1000);
		WebElement state2=driver.findElement(By.xpath(PropertyReader.getElementLocator("state2")));
		state2.click();
		
		Thread.sleep(1000);
		WebElement Choose_state2=driver.findElement(By.xpath(PropertyReader.getElementLocator("select_state")));
		Choose_state2.click();
		
		Thread.sleep(1000);
		WebElement Post=driver.findElement(By.id(PropertyReader.getElementLocator("Post_Code")));
		Post.sendKeys(PropertyReader.getElementLocator("ZIP_Code"));
		
		Thread.sleep(1000);
		WebElement email=driver.findElement(By.id(PropertyReader.getElementLocator("Email")));
		email.sendKeys(PropertyReader.getElementLocator("E_address"));
		
		Thread.sleep(1000);
		WebElement con_email=driver.findElement(By.id(PropertyReader.getElementLocator("Con_Email")));
		con_email.sendKeys(PropertyReader.getElementLocator("con_address"));
		
		Thread.sleep(1000);
		WebElement Phone=driver.findElement(By.id(PropertyReader.getElementLocator("Phone")));
		Phone.sendKeys(PropertyReader.getElementLocator("number"));
		
		
		Thread.sleep(1500);
		WebElement RACV_Num=driver.findElement(By.xpath("//input[@id='racvMemberNumber']"));
		RACV_Num.click();
		
		Thread.sleep(1000);
		Phone.click();
		
		 }
}