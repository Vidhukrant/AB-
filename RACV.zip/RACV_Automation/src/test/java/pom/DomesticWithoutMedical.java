package pom;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utility.PropertyReader;
import utility.SnapShots;

public class DomesticWithoutMedical {
	
	WebDriver driver=null;
	
	public DomesticWithoutMedical(WebDriver driver) {
		
		this.driver=driver;
	}
	
	public void Domestic_Flow() throws IOException {
		
		
		{
			
			try {
				
				
				driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
				JavascriptExecutor js=(JavascriptExecutor) driver;
				
				
				Thread.sleep(3000);
				WebElement ele=driver.findElement(By.id("country"));
				
				//js.executeScript("arguments[0].scrollIntoView();", ele);
				js.executeScript("window.scrollBy(0,400)");
				Thread.sleep(6000);
				WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator("Country")));
				contry.click();
				Thread.sleep(2000);
				contry.sendKeys(PropertyReader.getElementLocator("Domestic"));
				
				Thread.sleep(2000);
				WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator("Country_click")));
				Con_Click.click();
				
				WebElement Date=driver.findElement(By.id(PropertyReader.getElementLocator("Travel_Date")));
				
				Thread.sleep(2000);
				Date.sendKeys(PropertyReader.getElementLocator("Date"));
						
				Actions act=new Actions(driver);
				act.click();
				
				WebElement F_Age=driver.findElement(By.id(PropertyReader.getElementLocator("Age_First")));
				F_Age.sendKeys(PropertyReader.getElementLocator("Age1"));
				
				Thread.sleep(2000);
				WebElement AgeSecondry=driver.findElement(By.xpath(PropertyReader.getElementLocator("AgeSecondry")));
				AgeSecondry.sendKeys(PropertyReader.getElementLocator("Age2"));
				
				WebElement Dependents=driver.findElement(By.xpath(PropertyReader.getElementLocator("Dependents")));
				Dependents.sendKeys(PropertyReader.getElementLocator("Dep_No"));
				Thread.sleep(2000);
				WebElement state_click=driver.findElement(By.xpath(PropertyReader.getElementLocator("State")));
				state_click.click();
				
				Thread.sleep(2000);
				WebElement state=driver.findElement(By.xpath(PropertyReader.getElementLocator("State_Choose")));
				state.click();
				Thread.sleep(2000);
				
				WebElement RACV=driver.findElement(By.xpath(PropertyReader.getElementLocator("RACV")));
				RACV.click();
				Thread.sleep(2000);
				WebElement RACV_Mem= driver.findElement(By.xpath(PropertyReader.getElementLocator("RACV_Member")));
				RACV_Mem.click();
				Thread.sleep(2000);
				WebElement Get_Quote=driver.findElement(By.xpath(PropertyReader.getElementLocator("Get_Quote")));
				Get_Quote.click();
				
				Thread.sleep(3000);
				js.executeScript("window.scrollBy(0,700)");
				Thread.sleep(50000);
				WebElement conti=driver.findElement(By.xpath(PropertyReader.getElementLocator("Continue")));
				conti.click();
				js.executeScript("window.scrollBy(0,300)");
				
				Thread.sleep(1000);
				WebElement Pname=driver.findElement(By.id(PropertyReader.getElementLocator("First_Name")));
				Pname.sendKeys(PropertyReader.getElementLocator("Pfirst"));
				
				Thread.sleep(1000);
				WebElement Lname=driver.findElement(By.id(PropertyReader.getElementLocator("Last_Name")));
				Lname.sendKeys(PropertyReader.getElementLocator("Lfirst"));
				
				Thread.sleep(1000);
				WebElement DOB=driver.findElement(By.id(PropertyReader.getElementLocator("Primary_DOB")));
				DOB.sendKeys(PropertyReader.getElementLocator("DOB"));
				
				
				
				Thread.sleep(1000);
				WebElement SecondryFname=driver.findElement(By.xpath(PropertyReader.getElementLocator("SecondryFname")));
				SecondryFname.sendKeys(PropertyReader.getElementLocator("SecFname"));
				Thread.sleep(1000);
				WebElement SecondryLname=driver.findElement(By.xpath(PropertyReader.getElementLocator("SecondryLname")));
				SecondryLname.sendKeys(PropertyReader.getElementLocator("SecLname"));
				Thread.sleep(1000);
				WebElement SecondryDOB= driver.findElement(By.xpath(PropertyReader.getElementLocator("SecondryDOB")));
				SecondryDOB.sendKeys(PropertyReader.getElementLocator("SecDOB"));
				
				Thread.sleep(1000);
				WebElement address=driver.findElement(By.id(PropertyReader.getElementLocator("Address")));
				address.sendKeys(PropertyReader.getElementLocator("address"));
				
				Thread.sleep(3000);
				WebElement sub=driver.findElement(By.xpath(PropertyReader.getElementLocator("Suburb")));
				sub.sendKeys(PropertyReader.getElementLocator("sub"));
				
				Thread.sleep(1000);
				WebElement state2=driver.findElement(By.xpath(PropertyReader.getElementLocator("state2")));
				state2.click();
				
				Thread.sleep(1000);
				WebElement Choose_state2=driver.findElement(By.xpath(PropertyReader.getElementLocator("select_state")));
				Choose_state2.click();
				
				Thread.sleep(1000);
				WebElement Post=driver.findElement(By.id(PropertyReader.getElementLocator("Post_Code")));
				Post.sendKeys(PropertyReader.getElementLocator("ZIP_Code"));
				
				Thread.sleep(1000);
				WebElement email=driver.findElement(By.id(PropertyReader.getElementLocator("Email")));
				email.sendKeys(PropertyReader.getElementLocator("E_address"));
				
				Thread.sleep(1000);
				WebElement con_email=driver.findElement(By.id(PropertyReader.getElementLocator("Con_Email")));
				con_email.sendKeys(PropertyReader.getElementLocator("con_address"));
				
				Thread.sleep(1000);
				WebElement Phone=driver.findElement(By.id(PropertyReader.getElementLocator("Phone")));
				Phone.sendKeys(PropertyReader.getElementLocator("number"));
				
				 js.executeScript("window.scrollBy(0,200)");
				 
				 
				 
				 Thread.sleep(2000);
				 WebElement DependentFname=driver.findElement(By.xpath(PropertyReader.getElementLocator("DependentFname")));
				 DependentFname.sendKeys(PropertyReader.getElementLocator("DepFname"));
				 Thread.sleep(1000);
				 WebElement DependentLname= driver.findElement(By.xpath(PropertyReader.getElementLocator("DependentLname")));
				 DependentLname.sendKeys(PropertyReader.getElementLocator("DepLname"));
				 Thread.sleep(1000);
				 WebElement DepDOB=driver.findElement(By.xpath(PropertyReader.getElementLocator("DepDOB")));
				 DepDOB.sendKeys(PropertyReader.getElementLocator("DDOB"));
				 
				 
				 
				 
				 
				 js.executeScript("window.scrollBy(0,800)");
				 Thread.sleep(2000);
				 WebElement no=driver.findElement(By.xpath(PropertyReader.getElementLocator("No")));
				 no.click();
				 
				 Thread.sleep(1000);
				 WebElement cnf= driver.findElement(By.xpath(PropertyReader.getElementLocator("Confirm")));
				 cnf.click();
				 
				 Thread.sleep(9000);
				 js.executeScript("window.scrollBy(0,600)");
				 Thread.sleep(3000);
				 WebElement PDS_Condition=driver.findElement(By.xpath(PropertyReader.getElementLocator("PDS_Condition")));
				 PDS_Condition.click();
				 Thread.sleep(3000);
					 
				 act.sendKeys(Keys.TAB).perform();
				 
				 act.sendKeys(Keys.TAB).perform();
				 Thread.sleep(1000);
				 act.sendKeys(Keys.TAB).perform();
				 Thread.sleep(1000);
				 act.sendKeys(Keys.TAB).perform();
				 
				 act.sendKeys(Keys.TAB).perform();
	             act.sendKeys(Keys.TAB).perform();
				 
				 act.sendKeys(Keys.TAB).perform();
				 
				 act.sendKeys(Keys.TAB).perform();
	             act.sendKeys(Keys.TAB).perform();
				 
				 act.sendKeys(Keys.TAB).perform();
	             act.sendKeys(Keys.TAB).perform();
				 
				 act.sendKeys(Keys.TAB).perform();
	             act.sendKeys(Keys.TAB).perform();
				 
				 act.sendKeys(Keys.TAB).perform();
				 
				 act.sendKeys(Keys.TAB).perform();
	             act.sendKeys(Keys.TAB).perform();
				 
				 act.sendKeys(Keys.TAB).perform();
				 act.sendKeys(Keys.ENTER).perform();
				 
				 Thread.sleep(3000);
				 
				 js.executeScript("window.scrollBy(0,300)");
				 Thread.sleep(2000);
				 WebElement Card_Holder_Name=driver.findElement(By.id(PropertyReader.getElementLocator("Card_Holder_Name")));
				 Card_Holder_Name.sendKeys(PropertyReader.getElementLocator("Name"));
				 
				 Thread.sleep(3000);
	             new WebDriverWait(driver, 20).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector("iframe#braintree-hosted-field-number[src*='hosted-fields-frame']")));
	             WebElement cardnumber=driver.findElement(By.xpath(PropertyReader.getElementLocator("CC_Number")));
	             js.executeScript("window.scrollBy(0,200)");
	             cardnumber.sendKeys(PropertyReader.getElementLocator("Card_Num"));
	             driver.switchTo().defaultContent();

	             Thread.sleep(3000);
	             
	             new WebDriverWait(driver, 20).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector("iframe#braintree-hosted-field-expirationDate[src*='hosted-fields-frame']")));
	             WebElement expirationdt=driver.findElement(By.xpath(PropertyReader.getElementLocator("Expiry_date")));
	             expirationdt.sendKeys(PropertyReader.getElementLocator("Exp_Date"));
	             driver.switchTo().defaultContent();
	             
	             
	             Thread.sleep(3000);
	             new WebDriverWait(driver, 20).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector("iframe#braintree-hosted-field-cvv[src*='hosted-fields-frame']")));
	             WebElement cvv=driver.findElement(By.xpath(PropertyReader.getElementLocator("CVV")));
	             cvv.sendKeys(PropertyReader.getElementLocator("CVV_Num"));
	             driver.switchTo().defaultContent();
	             
	             Thread.sleep(2000);
	             WebElement cnf_pay=driver.findElement(By.xpath(PropertyReader.getElementLocator("Confirm_Pay")));
	             cnf_pay.click();
	             
	            // WebDriverWait Verify_Element=new WebDriverWait(driver, 100);
	             
	            // WebElement s=Verify_Element.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[text()='Payment Receipt']"))));
	            // s.getText();


			}
				catch(Exception e) {
					
					System.out.println(e);
					SnapShots.takeScreenshot(driver, "Fail");
					
				}
				
			
			}
		



	}

}
