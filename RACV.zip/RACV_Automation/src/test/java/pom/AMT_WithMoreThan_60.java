package pom;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import utility.PropertyReader;
import utility.SnapShots;

public class AMT_WithMoreThan_60 {
	
	WebDriver driver=null;
	
	public AMT_WithMoreThan_60(WebDriver driver) {
		
		this.driver=driver;
	}
	
	public void check_date_range() throws IOException {
		
		try {
			
			Thread.sleep(4000);
			WebElement AMT=driver.findElement(By.xpath("//*[text()='Annual Multi-Trip ']"));
			AMT.click();
			
			JavascriptExecutor js=(JavascriptExecutor) driver;
		
			js.executeScript("window.scrollBy(0,400)");
			
            WebElement Date=driver.findElement(By.id(PropertyReader.getElementLocator2("Travel_Date")));
			
			Thread.sleep(2000);
			Date.sendKeys(PropertyReader.getElementLocator2("Date"));
			Actions act=new Actions(driver);
			Thread.sleep(2000);
			WebElement ReturnDate= driver.findElement(By.xpath("//*[@id='returnDate']"));
			//act.sendKeys(Keys.CONTROL).sendKeys("A").build().perform();
			Thread.sleep(1000);
			ReturnDate.sendKeys(Keys.CONTROL +"a");
			ReturnDate.sendKeys(Keys.DELETE);
			
			Thread.sleep(2000);
			//act.sendKeys(Keys.CONTROL).sendKeys("A").build().perform();
			ReturnDate.sendKeys("16/06/2020");
			
			
		
		
	}
		
		catch (Exception e) {
			SnapShots.takeScreenshot(driver, "AMT with more than 60 days");
		}

}}
