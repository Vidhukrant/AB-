package pom;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import utility.PropertyReader;
import utility.SnapShots;

public class Test_Cases {
	
	WebDriver driver=null;
	
	public Test_Cases(WebDriver driver) {
		
		this.driver=driver;
	}
	
	public void AMT_Box() throws IOException {
		
		try {
			
			Thread.sleep(4000);
			WebElement AMT=driver.findElement(By.xpath("//*[text()='Annual Multi-Trip ']"));
			AMT.click();
	}
		catch (Exception e) {
			SnapShots.takeScreenshot(driver, "AMT Box not displayed");
		}

}
public void AMT_date_range() throws IOException {
		
		try {
			
			Thread.sleep(4000);
			WebElement AMT=driver.findElement(By.xpath("//*[text()='Annual Multi-Trip ']"));
			AMT.click();
			
			JavascriptExecutor js=(JavascriptExecutor) driver;
		
			js.executeScript("window.scrollBy(0,400)");
			
            WebElement Date=driver.findElement(By.id(PropertyReader.getElementLocator2("Travel_Date")));
			
			Thread.sleep(2000);
			Date.sendKeys(PropertyReader.getElementLocator2("Date"));
			Actions act=new Actions(driver);
			Thread.sleep(2000);
			WebElement ReturnDate= driver.findElement(By.xpath("//*[@id='returnDate']"));

			Thread.sleep(1000);
			ReturnDate.sendKeys(Keys.CONTROL +"a");
			ReturnDate.sendKeys(Keys.DELETE);
			
			Thread.sleep(2000);
			
			ReturnDate.sendKeys("16/06/2020");
			}
		
		catch (Exception e) {
			SnapShots.takeScreenshot(driver, "AMT with more than 60 days");
		}

}	

public void Country_Field() throws IOException {
	
	try {
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		WebElement ele=driver.findElement(By.id("country"));
		
		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(6000);
		WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator2("Country")));
		contry.click();
		Thread.sleep(2000);
		contry.sendKeys(PropertyReader.getElementLocator2("RACV_Domestic"));
		
		Thread.sleep(2000);
		WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator2("Country_click")));
		Con_Click.click();
	}
	
	catch (Exception e) {
		
		SnapShots.takeScreenshot(driver, "Country not appeared in list");
		
	}
}

public void Multiple_Countries() throws IOException {
	
try {
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		WebElement ele=driver.findElement(By.id("country"));
		
		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(6000);
		WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator2("Country")));
		contry.click();
		Thread.sleep(2000);
		contry.sendKeys(PropertyReader.getElementLocator2("RACV_Domestic"));
		
		Thread.sleep(2000);
		WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator2("Country_click")));
		Con_Click.click();
		
		Thread.sleep(2000);
		contry.sendKeys("India");
		Thread.sleep(1000);
		Con_Click.click();
	}
	
	catch (Exception e) {
		
		SnapShots.takeScreenshot(driver, "User is not able to select multiple countries");
		
	}
}

public void Remove_Countries() throws IOException {
	
try {
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		WebElement ele=driver.findElement(By.id("country"));
		
		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(6000);
		WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator2("Country")));
		contry.click();
		Thread.sleep(2000);
		contry.sendKeys(PropertyReader.getElementLocator2("RACV_Domestic"));
		
		Thread.sleep(2000);
		WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator2("Country_click")));
		Con_Click.click();
		Thread.sleep(2000);
		Con_Click.sendKeys(Keys.CONTROL + "a");
		Con_Click.sendKeys(Keys.DELETE);
		Thread.sleep(2000);
		
		
	}
	
	catch (Exception e) {
		
		SnapShots.takeScreenshot(driver, "User is not able to remove selected country");
		
	}
}

public void ListOfCountries() throws IOException {
	
try {
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		WebElement ele=driver.findElement(By.id("country"));
		
		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(6000);
		WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator2("Country")));
		
		contry.click();
		
		Thread.sleep(3000);
	
		
		
	}
	
	catch (Exception e) {
		
		SnapShots.takeScreenshot(driver, "List of  countries is not appeared");
		
	}
}

public void DoNotTravel() throws IOException {
	
try {
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		WebElement ele=driver.findElement(By.id("country"));
		
		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(6000);
		WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator2("Country")));
		contry.click();
		
		Thread.sleep(2000);
		contry.sendKeys("Fiji");
		
		Thread.sleep(2000);
		WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator2("Country_click")));
		Con_Click.click();
		
		
	}
	
	catch (Exception e) {
		
		SnapShots.takeScreenshot(driver, "DO not travel alert will not be populate");
		
	}
}

public void Validate_AgeForAMT() throws IOException {
	
try {
	
	   Thread.sleep(4000);
	   WebElement AMT=driver.findElement(By.xpath("//*[text()='Annual Multi-Trip ']"));
	   AMT.click();
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		WebElement ele=driver.findElement(By.id("country"));
		
		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(6000);
		WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator2("Country")));
		contry.click();
		
		Thread.sleep(2000);
		contry.sendKeys(PropertyReader.getElementLocator2("RACV_Domestic"));
		
		Thread.sleep(2000);
		WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator2("Country_click")));
		Con_Click.click();
		
		Thread.sleep(2000);
		 WebElement Date=driver.findElement(By.id(PropertyReader.getElementLocator2("Travel_Date")));
			
		Thread.sleep(2000);
		Date.sendKeys(PropertyReader.getElementLocator2("Date"));
			
		WebElement F_Age=driver.findElement(By.id(PropertyReader.getElementLocator2("Age_First")));
		F_Age.sendKeys("76");
		
		Thread.sleep(2000);
		driver.findElement(By.id("ageSecond")).click();
	
	}
	
	catch (Exception e) {
		
		SnapShots.takeScreenshot(driver, "Age validation for AMT trip");
		
	}
}
public void Validate_AgeForAMTLessThan18() throws IOException {
	
try {
	
	   Thread.sleep(4000);
	   WebElement AMT=driver.findElement(By.xpath("//*[text()='Annual Multi-Trip ']"));
	   AMT.click();
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		WebElement ele=driver.findElement(By.id("country"));
		
		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(6000);
		WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator2("Country")));
		contry.click();
		
		Thread.sleep(2000);
		contry.sendKeys(PropertyReader.getElementLocator2("RACV_Domestic"));
		
		Thread.sleep(2000);
		WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator2("Country_click")));
		Con_Click.click();
		
		Thread.sleep(2000);
		 WebElement Date=driver.findElement(By.id(PropertyReader.getElementLocator2("Travel_Date")));
			
		Thread.sleep(2000);
		Date.sendKeys(PropertyReader.getElementLocator2("Date"));
			
		WebElement F_Age=driver.findElement(By.id(PropertyReader.getElementLocator2("Age_First")));
		F_Age.sendKeys("15");
		
		Thread.sleep(3000);
		driver.findElement(By.id("ageSecond")).click();
	
	}
	
	catch (Exception e) {
		
		SnapShots.takeScreenshot(driver, "Age validation for AMT trip below 18");
		
	}
}

public void Validate_Dependent() throws IOException {
	
try {
	
	   Thread.sleep(4000);
	   WebElement AMT=driver.findElement(By.xpath("//*[text()='Annual Multi-Trip ']"));
	   AMT.click();
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		WebElement ele=driver.findElement(By.id("country"));
		
		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(6000);
		WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator2("Country")));
		contry.click();
		
		Thread.sleep(2000);
		contry.sendKeys(PropertyReader.getElementLocator2("RACV_Domestic"));
		
		Thread.sleep(2000);
		WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator2("Country_click")));
		Con_Click.click();
		
		Thread.sleep(2000);
		 WebElement Date=driver.findElement(By.id(PropertyReader.getElementLocator2("Travel_Date")));
			
		Thread.sleep(2000);
		Date.sendKeys(PropertyReader.getElementLocator2("Date"));
			
		WebElement F_Age=driver.findElement(By.id(PropertyReader.getElementLocator2("Age_First")));
		F_Age.sendKeys("20");
		
		Thread.sleep(2000);
		WebElement Dependent=driver.findElement(By.id("dependantCount"));
		Thread.sleep(2000);
		Dependent.sendKeys("1");
		
		Thread.sleep(3000);
	
	}
	
	catch (Exception e) {
		
		SnapShots.takeScreenshot(driver, "Validate number of dependent");
		
	}
}

public void State_Validate() throws IOException {
	
try {
	
	 
		
		this.Validate_Dependent();
		Thread.sleep(2000);
		WebElement state_click=driver.findElement(By.xpath(PropertyReader.getElementLocator2("State")));
		state_click.click();
	
	}
	
	catch (Exception e) {
		
		SnapShots.takeScreenshot(driver, "Validate State");
		
	}
}

public void SingleThanAMTTrip() throws IOException {
	
try {
	
	 Thread.sleep(4000);
	   WebElement ST=driver.findElement(By.xpath("//*[text()=' Single Trip ']"));
	   ST.click();
		
		this.Validate_AgeForAMT();
		JavascriptExecutor js=(JavascriptExecutor) driver;
		
		js.executeScript("window.scrollBy(0,-1000)");
		
		 WebElement AMT=driver.findElement(By.xpath("//*[text()='Annual Multi-Trip ']"));
		   AMT.click();
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,500)");
	
	}
	
	catch (Exception e) {
		
		SnapShots.takeScreenshot(driver, "SingleThanAMTTrip");
		
		
	}}

public void SingleTripDate() throws IOException {
	
try {
	
	 Thread.sleep(4000);
	   WebElement ST=driver.findElement(By.xpath("//*[text()=' Single Trip ']"));
	   ST.click();
		
	   JavascriptExecutor js=(JavascriptExecutor) driver;
		
		js.executeScript("window.scrollBy(0,300)");
		
       WebElement Date=driver.findElement(By.id(PropertyReader.getElementLocator2("Travel_Date")));
		
		Thread.sleep(2000);
		Date.sendKeys(PropertyReader.getElementLocator2("Date"));
		Actions act=new Actions(driver);
		Thread.sleep(2000);
		WebElement ReturnDate= driver.findElement(By.xpath("//*[@id='returnDate']"));

		Thread.sleep(1000);
		ReturnDate.sendKeys(Keys.CONTROL +"a");
		ReturnDate.sendKeys(Keys.DELETE);
		
		Thread.sleep(2000);
		
		ReturnDate.sendKeys("16/06/2020");
		
		
		js.executeScript("window.scrollBy(0,-1000)");
		
		 WebElement AMT=driver.findElement(By.xpath("//*[text()='Annual Multi-Trip ']"));
		   AMT.click();
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,500)");
	
	}
	
	catch (Exception e) {
		
		SnapShots.takeScreenshot(driver, "SingleTripDate");
		
		
	}
}

public void Coverage_Check() throws IOException {
	try {
		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		WebElement ele=driver.findElement(By.id("country"));
		
	
		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(6000);
		WebElement contry=driver.findElement(By.id(PropertyReader.getElementLocator2("Country")));
		contry.click();
		Thread.sleep(2000);
		contry.sendKeys(PropertyReader.getElementLocator2("Country_Name"));
		
		Thread.sleep(2000);
		WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getElementLocator2("Country_click")));
		Con_Click.click();
		
		WebElement Date=driver.findElement(By.id(PropertyReader.getElementLocator2("Travel_Date")));
		
		Thread.sleep(2000);
		Date.sendKeys(PropertyReader.getElementLocator2("Date"));
				
		Actions act=new Actions(driver);
		act.click();
		
		WebElement F_Age=driver.findElement(By.id(PropertyReader.getElementLocator2("Age_First")));
		F_Age.sendKeys(PropertyReader.getElementLocator2("Age1"));
		Thread.sleep(2000);
		WebElement state_click=driver.findElement(By.xpath(PropertyReader.getElementLocator2("State")));
		state_click.click();
		
		Thread.sleep(2000);
		WebElement state=driver.findElement(By.xpath(PropertyReader.getElementLocator2("State_Choose")));
		state.click();
		Thread.sleep(2000);
		
		WebElement RACV=driver.findElement(By.xpath(PropertyReader.getElementLocator2("RACV")));
		RACV.click();
		Thread.sleep(2000);
		WebElement RACV_Mem= driver.findElement(By.xpath(PropertyReader.getElementLocator2("RACV_Member")));
		RACV_Mem.click();
		Thread.sleep(2000);
		WebElement Get_Quote=driver.findElement(By.xpath(PropertyReader.getElementLocator2("Get_Quote")));
		Get_Quote.click();
		
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,800)");
	}
	catch (Exception e) {
		SnapShots.takeScreenshot(driver, "Coverage validate");
	}
}

public void ValidateEditOption() throws IOException, InterruptedException {
	
	this.Coverage_Check();
	JavascriptExecutor js=(JavascriptExecutor) driver;
	
	Thread.sleep(9000);
	js.executeScript("window.scrollBy(0,-300)");
	Thread.sleep(5000);
	driver.findElement(By.xpath("//a[@class='edit-icon']")).click();
}

public void ShowAllBenefit() throws IOException, InterruptedException {
	
	this.Coverage_Check();
	
	Thread.sleep(5000);
	WebElement Benefit=driver.findElement(By.xpath("//*[text()=' Show All Benefits ']"));
	Benefit.click();
	JavascriptExecutor js=(JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,700)");
	
	Thread.sleep(2000);
	js.executeScript("window.scrollBy(0,-700)");
}

public void Choose_Excess() throws IOException, InterruptedException {
	
	this.Coverage_Check();
	Thread.sleep(2000);
	JavascriptExecutor js=(JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,-300)");
	
	Thread.sleep(6000);
	WebElement Choose_Excess=driver.findElement(By.xpath("(//*[text()='$250'])[1]"));
	Choose_Excess.click();
	
}

}
