package pom;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utility.PropertyReader;
import utility.SnapShots;

public class DateValidationWithPastDate {
	
	WebDriver driver=null;
	
	public DateValidationWithPastDate(WebDriver driver) {
		
		this.driver=driver;
	}
			
	        public void PastDate() throws IOException {
	        	
	        	try {
	        		
			WebElement contry=driver.findElement(By.id(PropertyReader.getValidationMessage("Country")));
				
		    JavascriptExecutor js=(JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,350)");
			Thread.sleep(6000);
			
			contry.click();
			Thread.sleep(2000);
			contry.sendKeys(PropertyReader.getValidationMessage("Country_Name"));
				
			Thread.sleep(2000);
			WebElement Con_Click= driver.findElement(By.xpath(PropertyReader.getValidationMessage("Country_click")));
			Con_Click.click();
		
		    WebElement date=driver.findElement(By.id(PropertyReader.getValidationMessage("Travel_Date")));
		    date.sendKeys(PropertyReader.getValidationMessage("DatePast"));
		    
		    Thread.sleep(1000);
		    WebElement Age_First=driver.findElement(By.id(PropertyReader.getValidationMessage("Age_First")));
		    Age_First.click();
		
		
		
		
	}
	
	catch(Exception e) {
		
		System.out.println(e);
		SnapShots.takeScreenshot(driver, "Fail");
		
		
	}
	
}

	}


