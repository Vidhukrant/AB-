package base;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;

import utility.PropertyReader;

public class Base_RAC {
	
	public WebDriver  driver;
	public static ExtentReports report;
	
	@BeforeSuite
	public void startReporting()
	{
		report = new ExtentReports("./RAC_Report/Report.html");
		
	}
	
	@AfterSuite
	public void saveReport()
	{
		report.flush();
		report.close();
	}
	
	
	@BeforeMethod
	public void startBrowser() throws IOException, InterruptedException
	{
		if(PropertyReader.getProjectConfiguration("application_browser").equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
			driver = new ChromeDriver();
			
		}
		else if(PropertyReader.getProjectConfiguration("application_browser").equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "./Driver/chromedriver.exe");
			driver = new FirefoxDriver();
		}
		else if(PropertyReader.getProjectConfiguration("application_browser").equalsIgnoreCase("ie"))
		{
			
		}
		//driver.manage().timeouts().pageLoadTimeout(2, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(PropertyReader.getProjectConfiguration("RAC_URL"));
       
	}
	
	@AfterMethod
	public void closeBrowser()
	{
		driver.close();
	}
	

}
